/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, useScroll, useSpring, AnimatePresence } from 'motion/react';
import { Github, Linkedin, Mail, Terminal, Code2, Globe, Cpu, ArrowRight, X } from 'lucide-react';

const SKILLS = ['TypeScript', 'React', 'Node.js', 'Next.js', 'Tailwind CSS', 'Python', 'PostgreSQL', 'Docker'];

const PROJECTS = [
  {
    title: 'E-Commerce Platform',
    desc: 'A full-stack application with real-time inventory and Stripe integration.',
    longDesc: 'Built a comprehensive e-commerce platform that handles product cataloging, user authentication, a shopping cart, and seamless checkout via Stripe. Implemented a real-time inventory synchronization system using websockets to ensure accurate stock levels. The admin dashboard allows for order management and analytics.',
    tags: ['React', 'Node.js', 'PostgreSQL'],
    icon: Globe,
    github: 'https://github.com',
    live: 'https://example.com'
  },
  {
    title: 'AI Developer Tool',
    desc: 'CLI tool that generates boilerplate code using LLMs.',
    longDesc: 'A productivity-enhancing command-line interface tool designed to rapid-prototype application structures. By integrating with the OpenAI API, it interprets natural language prompts and scaffolds complete, functional project boilerplates across various frameworks, complete with tests and documentation.',
    tags: ['TypeScript', 'OpenAI API', 'CLI'],
    icon: Terminal,
    github: 'https://github.com',
    live: 'https://example.com'
  },
  {
    title: 'Data Analytics Dashboard',
    desc: 'Real-time visualizations for tracking marketing campaigns.',
    longDesc: 'Developed a rich, interactive data dashboard tailored for marketing teams to monitor campaign performance. Utilized D3.js to craft bespoke, responsive charts and graphs that consume a real-time data feed from Firebase, enabling instantaneous insights and data-driven decision making.',
    tags: ['Vue.js', 'D3.js', 'Firebase'],
    icon: Cpu,
    github: 'https://github.com',
    live: 'https://example.com'
  },
];

export default function App() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });
  
  const [selectedProject, setSelectedProject] = useState<typeof PROJECTS[0] | null>(null);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-[#e0ff00]/30 selection:text-[#e0ff00]">
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-[#e0ff00] origin-left z-[60]"
        style={{ scaleX }}
      />
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0a]/80 backdrop-blur-md border-b border-white/10">
        <div className="max-w-5xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="text-xs font-bold tracking-[0.3em] uppercase text-white">
            Portfolio / 2024
          </div>
          <div className="flex gap-8 text-[10px] md:text-xs font-bold tracking-[0.2em] md:tracking-[0.3em] uppercase text-gray-400">
            <a href="#about" className="hover:text-[#e0ff00] transition-colors hidden sm:block">About</a>
            <a href="#projects" className="hover:text-[#e0ff00] transition-colors">Works</a>
            <a href="#contact" className="hover:text-[#e0ff00] transition-colors">Contact</a>
          </div>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-6 pt-32 pb-12 space-y-32">
        {/* Hero Section */}
        <section className="flex flex-col items-start pt-12 md:pt-24 relative z-10 w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col md:flex-row items-start md:items-end gap-2 md:gap-4 mb-2 md:mb-[-20px]"
          >
            <span className="text-[#e0ff00] text-sm font-mono mb-0 md:mb-6">[00]</span>
            <motion.h1
              className="text-7xl md:text-[220px] font-black tracking-tighter leading-[0.8] uppercase select-none italic text-white"
            >
              MAAZ
            </motion.h1>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-col md:flex-row justify-between items-start w-full gap-8 mt-8"
          >
            <motion.p
              className="max-w-md text-lg leading-relaxed text-gray-400"
            >
              A creative laboratory specializing in digital experiences, minimalist interfaces, and bold architectural design for the next generation of web users.
            </motion.p>
            <div className="flex flex-col items-start md:items-end gap-2 border-l-2 md:border-l-0 md:border-r-2 border-[#e0ff00] pl-4 md:pl-0 md:pr-4 py-1">
               <div className="text-4xl md:text-[64px] font-light leading-none text-white">32.5°</div>
               <div className="text-[10px] tracking-[0.2em] text-gray-500 uppercase mt-2">Current Node: London</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex flex-wrap items-center gap-6 mt-16"
          >
            <a
              href="#projects"
              className="text-xs font-bold tracking-[0.3em] uppercase bg-[#e0ff00] hover:bg-white text-black px-8 py-4 transition-colors flex items-center gap-3 border border-[#e0ff00] hover:border-white"
            >
              View Works
              <ArrowRight size={16} />
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              className="p-3 text-gray-400 hover:text-[#e0ff00] transition-colors border border-transparent hover:border-white/10"
            >
              <Github size={20} />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noreferrer"
              className="p-3 text-gray-400 hover:text-[#e0ff00] transition-colors border border-transparent hover:border-white/10"
            >
              <Linkedin size={20} />
            </a>
          </motion.div>
        </section>

        {/* About Section */}
        <section id="about" className="scroll-mt-32">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="space-y-12"
          >
            <h3 className="text-sm font-bold tracking-[0.3em] uppercase text-white flex items-center gap-4">
              <span className="text-[#e0ff00] font-mono">[01]</span>
              About Me
              <div className="h-px bg-white/10 flex-1 md:max-w-[400px]" />
            </h3>
            
            <div className="grid md:grid-cols-[1fr_300px] gap-12 lg:gap-24">
              <div className="space-y-6 text-gray-400 leading-relaxed font-light text-base md:text-lg">
                <p>
                  Hello! My name is Maaz and I enjoy creating things that live on the internet. 
                  My interest in web development started back when I decided to try editing custom Tumblr themes — turns out hacking together HTML & CSS taught me a lot about architecture!
                </p>
                <p>
                  Fast-forward to today, and I've had the privilege of working at an advertising agency, a start-up, a huge corporation, and a student-led design studio.
                </p>
                <p className="text-white pt-4 text-sm tracking-[0.1em] uppercase font-bold">Technologies of choice:</p>
                
                <ul className="grid grid-cols-2 gap-4 mt-6 font-mono text-xs text-gray-400">
                  {SKILLS.map((skill) => (
                    <li key={skill} className="flex items-center gap-3">
                      <span className="text-[#e0ff00] text-[10px]">▹</span> {skill}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative group w-full max-w-[300px] mx-auto md:mx-0">
                <div className="absolute inset-0 bg-[#e0ff00] opacity-10 translate-x-4 translate-y-4 transition-transform duration-500 group-hover:translate-x-2 group-hover:translate-y-2 border border-[#e0ff00]/30" />
                <div className="relative aspect-[3/4] bg-[#111] overflow-hidden border border-white/10 flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-500 z-10">
                  <img src="/profile.jpg" alt="Maaz" className="w-full h-full object-cover" />
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="scroll-mt-32">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            className="space-y-12"
          >
            <h3 className="text-sm font-bold tracking-[0.3em] uppercase text-white flex items-center gap-4">
              <span className="text-[#e0ff00] font-mono">[02]</span>
              Works
              <div className="h-px bg-white/10 flex-1 md:max-w-[400px]" />
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {PROJECTS.map((project, i) => {
                const Icon = project.icon;
                return (
                  <motion.div
                    key={project.title}
                    initial={{ opacity: 0, y: 20, scale: 0.95 }}
                    whileInView={{ opacity: 1, y: 0, scale: 1 }}
                    whileHover={{ scale: 1.03 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.4, delay: i * 0.1 }}
                    className="p-8 bg-[#0a0a0a] border border-white/10 hover:bg-[#111] hover:shadow-[0_15px_30px_-10px_rgba(224,255,0,0.15)] transition-colors duration-300 group flex flex-col h-full relative overflow-hidden cursor-pointer z-10 hover:z-20"
                    onClick={() => setSelectedProject(project)}
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-[#e0ff00]/5 rounded-bl-full -translate-y-full translate-x-full group-hover:translate-y-0 group-hover:translate-x-0 transition-transform duration-500" />
                    
                    <div className="flex justify-between items-start mb-8 relative z-10">
                      <Icon size={24} className="text-[#e0ff00]" />
                      <div className="flex gap-4 text-gray-500">
                        <a href={project.github} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>
                           <Github size={18} className="hover:text-[#e0ff00] transition-colors cursor-pointer" />
                        </a>
                        <a href={project.live} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>
                           <Globe size={18} className="hover:text-[#e0ff00] transition-colors cursor-pointer" />
                        </a>
                      </div>
                    </div>
                    
                    <h4 className="text-xl font-serif italic text-white mb-4 group-hover:text-[#e0ff00] transition-colors relative z-10">
                      {project.title}
                    </h4>
                    <p className="text-gray-400 text-sm leading-relaxed flex-1 relative z-10 font-light">
                      {project.desc}
                    </p>
                    <div className="mt-8 pt-4 border-t border-white/10 flex flex-wrap gap-x-4 gap-y-2 text-[10px] tracking-[0.2em] font-bold uppercase text-gray-500 relative z-10 group-hover:border-[#e0ff00]/30 transition-colors">
                      {project.tags.map((tag) => (
                        <span key={tag}>{tag}</span>
                      ))}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="scroll-mt-32 pb-24 border-t border-white/10 pt-24 mt-32">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="flex flex-col items-center text-center space-y-8 max-w-2xl mx-auto"
          >
            <p className="text-sm font-bold tracking-[0.3em] uppercase text-[#e0ff00] font-mono">[03]</p>
            <h3 className="text-5xl md:text-7xl font-serif italic text-white">Get In Touch</h3>
            <p className="text-gray-400 leading-relaxed text-lg font-light max-w-lg">
              Although I'm not currently looking for any new opportunities, my inbox is always open. 
              Whether you have a question or just want to say hi, I'll try my best to get back to you.
            </p>
            <a
              href="mailto:maazkamal67@gmail.com"
              className="mt-8 px-8 py-4 border border-white/30 text-white hover:border-[#e0ff00] hover:text-[#e0ff00] transition-colors text-xs tracking-[0.3em] font-bold uppercase inline-flex items-center gap-4 group"
            >
              <Mail size={16} className="group-hover:scale-110 transition-transform" />
              Transmit Message
            </a>
          </motion.div>
        </section>
      </main>

      <footer className="border-t border-white/10 bg-[#0a0a0a]">
        <div className="grid grid-cols-1 md:grid-cols-2 max-w-5xl mx-auto w-full">
          <div className="p-10 border-b md:border-b-0 md:border-r border-white/10 bg-[#111]">
            <h3 className="text-[#e0ff00] text-[10px] font-bold tracking-[0.4em] uppercase mb-4">Visual Strategy</h3>
            <p className="text-sm text-gray-400 font-light leading-relaxed">Breaking conventions through high-contrast typography and intentional whitespace usage.</p>
          </div>
          <div className="p-10 flex flex-col justify-between min-h-[160px]">
            <div className="flex flex-wrap gap-8 text-[10px] tracking-widest uppercase text-gray-500">
              <span className="hover:text-[#e0ff00] cursor-pointer transition-colors">Instagram</span>
              <span className="hover:text-[#e0ff00] cursor-pointer transition-colors">Behance</span>
              <span className="hover:text-[#e0ff00] cursor-pointer transition-colors">X / Twitter</span>
            </div>
            <div className="text-[10px] text-gray-600 uppercase tracking-widest mt-8 md:mt-0 font-medium">
              &copy; 2024 Maaz Creative Studio. All Rights Reserved.
            </div>
          </div>
        </div>
      </footer>

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
              className="absolute inset-0 bg-[#0a0a0a]/90 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full max-w-3xl bg-[#111] border border-white/20 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
               <button 
                onClick={() => setSelectedProject(null)}
                className="absolute top-6 right-6 text-gray-500 hover:text-[#e0ff00] z-10 transition-colors"
                aria-label="Close modal"
              >
                <X size={24} />
              </button>

              <div className="p-8 md:p-12 overflow-y-auto custom-scrollbar">
                <div className="flex items-center gap-4 mb-6">
                   <div className="p-3 bg-[#0a0a0a] border border-white/10 rounded-sm">
                      {selectedProject.icon && <selectedProject.icon size={32} className="text-[#e0ff00]" />}
                   </div>
                   <h3 className="text-3xl md:text-5xl font-serif italic text-white leading-tight">
                     {selectedProject.title}
                   </h3>
                </div>
                
                <div className="h-px bg-white/10 w-full mb-8" />
                
                <div className="prose prose-invert max-w-none text-gray-300 font-light leading-relaxed mb-10">
                  <p className="text-lg md:text-xl text-gray-400 mb-6 font-medium">{selectedProject.desc}</p>
                  <p className="whitespace-pre-wrap">{selectedProject.longDesc}</p>
                </div>

                <div className="grid md:grid-cols-2 gap-10">
                  <div>
                    <h4 className="text-[10px] font-bold tracking-[0.3em] uppercase text-gray-500 mb-4">Technologies</h4>
                    <div className="flex flex-wrap gap-2">
                       {selectedProject.tags.map(tag => (
                         <span key={tag} className="px-3 py-1.5 text-xs font-mono text-[#e0ff00] bg-[#e0ff00]/5 border border-[#e0ff00]/20 rounded-sm">
                           {tag}
                         </span>
                       ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold tracking-[0.3em] uppercase text-gray-500 mb-4">External Links</h4>
                    <div className="flex flex-col gap-3">
                       {selectedProject.github && (
                         <a href={selectedProject.github} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-gray-300 hover:text-[#e0ff00] text-sm group transition-colors">
                           <Github size={16} className="group-hover:scale-110 transition-transform" />
                           <span>View Source on GitHub</span>
                         </a>
                       )}
                       {selectedProject.live && (
                         <a href={selectedProject.live} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-gray-300 hover:text-[#e0ff00] text-sm group transition-colors">
                           <Globe size={16} className="group-hover:scale-110 transition-transform" />
                           <span>Visit Live Project</span>
                         </a>
                       )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
